create table tarefa (
 	id int PRIMARY KEY AUTO_INCREMENT,
    titulo varchar(300) not null,
    descricao varchar(600)
);