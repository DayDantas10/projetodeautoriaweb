CREATE TABLE `Produtos` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`produto` varchar(100) NOT NULL,
	PRIMARY KEY (`Id`)
);
