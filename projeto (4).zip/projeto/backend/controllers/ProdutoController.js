const express = require('express');
const router = express.Router();
const db = require('../util/db');

/**
 * Executa uma consulta no banco de dados e envia uma resposta.
 * @param {string} sql - A consulta SQL a ser executada.
 * @param {Array} params - Os parâmetros para a consulta SQL.
 * @param {Object} res - O objeto de resposta do Express.
 * @param {string} erroMsg - Mensagem de erro para ser enviada em caso de falha.
 */
function executarConsulta(sql, params, res, erroMsg) {
  db.query(sql, params, (err, result) => {
    if (err) {
      res.status(500).json({ erro: erroMsg, detalhes: err });
    } else {
      res.status(200).json(result);
    }
  });
}

// Rota para buscar todas as produtos
router.get('/', (req, res) => {
  executarConsulta('SELECT * FROM produtos', [], res, "Erro na consulta de produtos");
});

// Rota para buscar uma produto específica
router.get("/:id", (req, res) => {
  const id = req.params.id;
  executarConsulta('SELECT * FROM produtos WHERE id = ?', [id], res, "Erro na consulta de produto");
});

// Rota para criar uma nova produto
router.post('/', (req, res) => {
  const { produto } = req.body;
  executarConsulta('INSERT INTO produtos (produto) VALUES (?)', [produto], res, "Erro no cadastro de produto!");
});

// Rota para deletar uma produto
router.delete("/:id", (req, res) => {
  const produtoId = req.params.id;
  executarConsulta('DELETE FROM produtos WHERE id = ?', [produtoId], res, 'Erro ao deletar produto');
});

// Rota para atualizar uma produto
router.put('/', (req, res) => {
  const { id,  produto} = req.body;
  executarConsulta('UPDATE produtos SET produto = ? WHERE id = ?', [produto, id], res, "Erro ao atualizar produto");
});

module.exports = router;