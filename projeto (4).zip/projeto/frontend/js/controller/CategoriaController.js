import categoriaView from "../view/CategoriaView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de categoria.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarCategoriaFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = categoriaView.renderizarFormulario();
  document.getElementById("formulario_categoria").addEventListener("submit", cadastrarCategoria);
}

/**
 * Cadastra uma nova categoria.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrarCategoria(event) {
  event.preventDefault();
  const categoriaValor = document.getElementById("categoria_categoria_formulario").value;
  const novaCategoria = { categoria: categoriaValor };

  try {
    await fetch(`${API_BASE_URL}/categorias`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novaCategoria),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListaCategoria(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar categoria:", error);
  }
}
/**
 * Renderiza a lista de categorias.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListaCategoria(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/categorias");
    const categoriasBD = await response.json(); 

    const categoria = categoriasBD.map((row) => {
      return {
        id: row.id,
        categoria: row.categoria,
        dataAbertura: row.data_abertura,
      };
    });
    componentePrincipal.innerHTML = categoriaView.renderizarTabela(categoria);
    inserirEventosExcluir();
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar categoria:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de categoria.
 * Cada botão, quando clicado, aciona a função de exclusão de categoria correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const categoriaId = this.getAttribute("categoria-id");
      excluirCategoria(categoriaId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de categoria.
 * Cada botão, quando clicado, aciona a função de buscar a categoria específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const categoriaId = this.getAttribute("categoria-atualizar-id");
      buscarCategoria(categoriaId);
    });
  });
}

/**
 * Exclui uma categoria específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de categorias é atualizada.
 * @param {string} id - ID da categoria a ser excluída.
 */
async function excluirCategoria(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/categorias/${id}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir a categoria");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaCategoria(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir a categoria:", error);
  }
}

/**
 * Busca uma categoria específica para atualização, com base no ID.
 * Após encontrar a categoria, renderiza o formulário de atualização.
 * @param {string} id - ID da categoria a ser buscada.
 */
async function buscarCategoria(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/categorias/${id}`);
    const categoriasBD = await response.json();
    if (categoriasBD.length <= 0) return;

    const categoria = categoriasBD.map(row => ({
      id: row.id,
      categoria: row.categoria,
      dataAbertura: row.data_abertura,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = categoriaView.renderizarFormularioAtualizar(categoria);
    document.getElementById("formulario_categoria_atualizar").addEventListener("submit", atualizarCategoria);
  } catch (error) {
    console.error("Erro ao buscar categoria:", error);
  }
}

/**
 * Atualiza uma categoria específica.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizarCategoria(event) {
  event.preventDefault();

  const idValor = document.getElementById("categoria_id_formulario").value;
  const categoriaValor = document.getElementById("categoria_categoria_formulario").value;
  const categoria = {id: idValor, categoria: categoriaValor};

  try {
    const response = await fetch(`${API_BASE_URL}/categorias`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(categoria),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar a categoria");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaCategoria(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar categoria:", error);
  }
}

const CategoriaController = {
  renderizarCategoriaFormulario,
  cadastrarCategoria,
  renderizarListaCategoria,
  excluirCategoria,
};

export default CategoriaController;
