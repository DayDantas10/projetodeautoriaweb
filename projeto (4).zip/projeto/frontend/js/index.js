import produtoController from "../js/controller/ProdutoController.js";
import categoriaController from "./controller/CategoriaController.js";



// Função auxiliar para selecionar elementos no DOM.
const $ = document.querySelector.bind(document);
const componentePrincipal = $("#conteudo_principal");

// Renderiza a lista de produtos como visualização inicial.
produtoController.renderizarListaProdutos(componentePrincipal);

/**
 * Fecha a barra de navegação lateral (navbar).
 */
function fecharNavBar() {
  const closeCanvas = document.querySelector('[data-bs-dismiss="offcanvas"]');
  closeCanvas.click();
}

/**
 * Configura o evento de clique para o item de menu 'Tarefa'.
 * Fecha a navbar e renderiza o formulário de produto.
 */
$("#produto").addEventListener("click", () => {
  fecharNavBar();
  produtoController.renderizarProdutoFormulario(componentePrincipal);
});

/**
 * Configura o evento de clique para o item de menu 'Lista de Tarefas'.
 * Fecha a navbar e renderiza a lista de produtos.
 */
$("#lista_produto").addEventListener("click", () => {
  fecharNavBar();
  produtoController.renderizarListaProdutos(componentePrincipal);
});

/**
 * Configura o evento de clique para o item de menu 'Tarefa'.
 * Fecha a navbar e renderiza o formulário de produto.
 */
$("#categoria").addEventListener("click", () => {
  fecharNavBar();
  categoriaController.renderizarCategoriaFormulario(componentePrincipal);
});

/**
 * Configura o evento de clique para o item de menu 'Tarefa'.
 * Fecha a navbar e renderiza o formulário de produto.
 */
$("#lista_categoria").addEventListener("click", () => {
  fecharNavBar();
  categoriaController.renderizarListaCategoria(componentePrincipal);
});