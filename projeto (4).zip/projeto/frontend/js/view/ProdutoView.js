/**
 * Renderiza o formulário para criar uma nova produto.
 * @return {string} HTML do formulário de criação de produto.
 */
function renderizarFormulario() {
  return `
          <form class="mt-3" id="formulario_produto">
              <div class="form-group">
                  <label for="produto_produto"> Nome do Produto:</label>
                  <textarea class="form-control" id="produto_produto_formulario"></textarea>
              </div>
              <button type="submit" class="btn btn-primary mt-2">Salvar</button>
          </form>

          
      `;
}

/**
 * Renderiza o formulário para atualizar uma produto existente.
 * @param {Object} produto - A produto a ser atualizada.
 * @return {string} HTML do formulário de atualização de produto.
 */
function renderizarFormularioAtualizar(produto) {
    return `
            <form class="mt-3" id="formulario_produto_atualizar">
                <input type="hidden" class="form-control" id="produto_id_formulario" value="${produto.id}">
                <div class="form-group">
                    <label for="produto_produto"> Nome do Produto:</label>
                    <input type="text" class="form-control" id="produto_produto_formulario" value="${produto.produto}">
                </div>
               
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
}

  /**
 * Renderiza a tabela de produtos.
 * @param {Array} produtos - Lista de produtos a serem exibidas.
 * @return {string} HTML da tabela de produtos.
 */
function renderizarTabela(produtos) {
  let tabela = `
          <table class="table table-striped mt-3">
              <thead>
                  <tr>
                      <th>Título do produto</th>
                  </tr>
              </thead>
              <tbody>
      `;

  produtos.forEach((produto) => {
    tabela += `
              <tr>
                  <td>${produto.produto}</td>
                  <td>
                    <button class="excluir-btn" produto-id=${produto.id}>Excluir</button>
                    <button class="atualizar-btn" produto-atualizar-id=${produto.id}>Atualizar</button>
                  </td>
              </tr>
          `;
  });

  tabela += `
              </tbody>
          </table>
      `;

  return tabela;
}

const ProdutoView = {
    renderizarFormulario,
    renderizarTabela,
    renderizarFormularioAtualizar
};

export default ProdutoView;
